window.Krux||((Krux=function(){Krux.q.push(arguments);}).q=[]);
(function() {
  var clients = {
      'alma': 'bc03044e-27cd-4792-b071-00ca485d3d29',
      'ami': 'e3dffe08-3ae7-434d-9ebe-62c898f84a7a',
      'atl': '2f0b1245-61c7-4b29-9468-1d7686aa6dab',
      'a360': 'd3b43385-17af-4ded-a596-e7fb14cfb091',
      'besweetcreations': '59fae095-095d-46b1-a9a4-b9a0af0dfbb5',
      'bloom': '0ccccb05-8c21-4099-9838-fed4ceb7a239',
      'burl': '16d0cec0-72a2-4a16-802c-8233f7dbdcdb',
      'busin': '08ea07b8-908f-4d41-b3b3-2af0d93a5984',
      'cag': '53f13a23-c936-4f28-a6e1-8c94be836e4e',
      'cars': 'f1c061b9-c7fc-4dd4-8a51-39acb1f4a41e',
      'carmax': '6b8da686-2384-44b3-bbf9-99e2e44c6724',
      'centro': '7b3785dc-e5e8-4465-88e8-0bb2db048533',
      'clorox': 'f447318e-f660-4a93-bda2-774f39204bee',
      'dailybeast': '931d64b2-4c01-4e13-90c6-6fb0837728a9',
      'davidsbridal': '1c369ceb-33c9-47d4-8cee-8833f921d2e2',
      'dmedia': '66822801-aa35-4f0d-a6ab-78970028f03f',
      'exp': '3d8e4b51-b537-4841-9086-4f59862457c6',
      'esi': '8dc3c31a-331c-4c9b-a044-a82b2e82e330',
      'forb': '7c727c7f-01f2-46b1-bafa-55662a7e6db8',
      'foxnews': '1ec99b1c-44a5-4b51-bb4a-4d1543830ca0',
      'fut': '31c1ae6b-6f4f-45a3-9bad-d4aad9c3af60',
      'gawk': 'f957ee1a-d222-492b-b86e-4b6eba139638',
      'gam' : 'bfb3d1d9-6a65-4dad-90d0-d5d134b9c7af',
      'jetblue': '5d3a6c7b-c015-447c-a038-7762f3c3b014',
      'kel': '696bde53-e9e2-4205-84af-cde254e436fb',
      'kgo': 'a5fbc948-51af-49e7-89ff-5e82fdd54e94',
      'liberty': '553cca40-fb9e-408b-9f9c-023fa9d83162',
      'lowes': 'e30196c7-5053-416c-94a4-c1acfb09b619',
      'man': 'f2aaa14d-71b0-4cbc-a074-0d62423d7764',
      'maxis':'0c0ae73d-67b7-4e7f-a70d-37da5587dd34',
      'mcdonaldsau': '2e4e2360-cf76-4648-bbf6-ba854143e5c6',
      'mediamarktde': '8ea45d5c-87dd-4b54-8770-e66941217c84',
      'mere': '1b008fc9-b074-4b2e-8e4a-c1e1f07d344b',
      'mercedes': 'a318064c-c214-46cb-8e1a-1c0e53deb350',
      'mlb': '8a5beb1e-7c54-4a9b-802f-9b064436798e',
      'mlz': '66b7958c-e7be-4c99-8484-175973202867',
      'nbc': '54983c83-8810-4a6b-9ff1-81f7349ce967',
      'newsau': '55a706c4-1321-4c4c-8f5e-d12afa1083a0',
      'newsiq': 'cfb269f3-9277-49a1-9908-731bf0894748',
      'nova': '66dc9621-3278-41dd-9d23-f0eebaecc88a',
      'nyp': '004480f6-3846-481a-abb4-46a3293402ae',
      'nyt': '79816aa8-435a-471a-be83-4b3e0946daf2',
      'padsquad': '55a37e72-39ae-4798-bcb5-f2690865b3aa',
      'pandora': '992b4e94-c474-4717-82db-512456587844',
      'pga': '5e601765-9a1c-4f9c-a7dd-492f3d5dbd9c',
      'reagroup': '2ac9e72c-f5c4-414d-9087-6d7a4ef581a9',
      'salp': '88a388a7-f531-4ebc-929a-e93320909d66',
      'sanoma': '9ae1de1e-f2f8-4599-a15e-eb921b259f51',
      'saturnde': 'ea1c15d1-7675-4e87-a751-c79676776dcd',
      'stub': 'c85ae0d6-9ed3-4bea-8377-9df2cfc3499',
      'trib': 'ed0a1b17-4fcc-461f-801f-5b1a729fa84d',
      'trust': '700bca2a-e4ec-4f23-be94-47317652bac0',
      'tur': 'e9eaedd3-c1da-4334-82f0-d7e3ff883c87',
      'uber': 'ba90b137-76aa-42ec-8c15-08f1a7670ed9',
      'vail': '5fe4c117-d66b-4264-89e1-feae9c18213e',
      'vice': 'e959415e-6d78-4761-bd97-5f3693023670',
      'vox': '36b99e73-5c79-40db-9954-69f256f24981',
      'wapo': '415dda7b-13ba-40f3-9a60-eb3ba310f160',
      'wenn': '2e379285-4c71-4e15-bc41-4d8cfe3ec56c',
  };

  var partners = {
      '5b0a9e4a-b3f4-4c19-a633-10fce940f97b': ['pandora', 'cag', 'carmax', 'vail', 'jetblue', 'lowes', 'mediamarktde', 'mercedes', 'saturnde',
                                               'mcdonaldsau','sanoma', 'reagroup', 'davidsbridal', 'besweetcreations', 'clorox', 'stub', 'kel', 'burl', 'liberty'],
      '786e1ff0-cc85-42cf-954e-8e0142346699': ['cag', 'mlz'],
      'a272cefb-df39-4fcd-beff-79cd6cdf22ec': ['ami', 'atl', 'bloom', 'busin', 'cars', 'centro', 'clorox', 'dailybeast', 'dmedia', 'esi', 'forb', 'fut',
                                               'gam', 'gawk', 'kel', 'kgo', 'man', 'mere', 'nbc', 'nyp', 'nyt', 'pga',
                                               'salp', 'trib', 'trust', 'tur', 'uber', 'vice', 'vox','wapo', 'wenn', 'mlb', 'foxnews'],
      '2d75e075-ec6a-4ba4-9c39-58bbe2f38f49': ['exp'],
      '451cb99c-2a54-41d7-afee-4b9f98e9d6da': ['maxis', 'newsau', 'padsquad', 'wapo', 'a360', 'vice', 'mere', 'alma', 'nova'],
      'b38e51b1-bc0f-4bfb-a031-50ad7099aaa7': ['newsiq']
  };

  var now = function() {
    return new Date().getTime();
  };

  var get_item = function(key) {
    try {
      var entry = JSON.parse(localStorage.getItem(key)||"0");
      if (!entry) {
        return null;
      }
      if (entry.ttl && entry.ttl + entry.now < now()) {
        localStorage.removeItem(key);
        return null;
      }
      return entry.value;
    } catch (e) {
      return null;
    }
  };

  var set_item = function(key, value, ttl ) {
    try {
      localStorage.setItem( key, JSON.stringify({
        ttl   : ttl || 0,
        now   : now(),
        value : value
      }) );
    } catch (e) { /* Ignore security error on Safari */ }
  };

  var get_query_parameters = function(params) {
    if (!params) {
      return {};
    }
    var ret = {};
    for (var i = 0; i < params.length;++i) {
      var param=params[i].split('=', 2);
      if (param.length == 1) {
        ret[param[0]] = "";
      } else {
        ret[param[0]] = decodeURIComponent(param[1].replace(/\+/g, " "));
      }
    }
    return ret;
  };

  var lookup_client = function() {
    var partner = '';
    var client = '';
    var nodes = document.getElementsByTagName('script');
    var limit = nodes.length;
    while (limit--) {
      var src = nodes[limit].src;
      if (/^https?:\/\/cdn(-stage)?.krxd.net\/partnerjs\/segments_to_partner\.js/.test(src || '')) {
        params = get_query_parameters(src.split('?', 2)[1].split('&'));
        client = params["client"];
        partner = params["partner"];
        break;
      }
    }
    if (partner in partners) {
      var partner_clients = partners[partner];
      if (partner_clients.indexOf(client) >= 0) {
        return client;
      }
    }
    return '';
  };

  kx_partner_segments = function(segment_json) {
    var k = client + '_segments',
    u = client + '_kuid',
    kv = [], 
    uv = "";

    if (segment_json && segment_json.body) {
      if(segment_json.body.segments){
        kv =  segment_json.body.segments;
      }
      if (segment_json.body.kuid) {
        uv =  segment_json.body.kuid;
      } 
    }

    Krux[k] = kv;
    set_item(k, kv, 600000); // Wait for 10 min

    Krux[u] = uv;
    set_item(u, uv, 600000); // Wait for 10 min
  };

  var client = lookup_client();
  if (client) {
    var key = client + '_segments',
    kuid_key = client + '_kuid',
    segs = get_item(key),
    kuid = get_item(kuid_key);

    if (segs && kuid) {
      Krux[key] = segs;
      Krux[kuid_key] = kuid;

    } else {
      var client_id = clients[client];
      if (client_id) {
        var script = document.createElement('script');
        script.src = "https://cdn.krxd.net/userdata/get?pub="+client_id+"&callback=kx_partner_segments";
        var sibling = document.getElementsByTagName('script')[0];
        sibling.parentNode.insertBefore(script, sibling);
      }
    }
  }
})();
